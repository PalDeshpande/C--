/*
 * Friend.h
 *
 *  Created on: Apr 22, 2012
 *      Author: Pallavi
 */

#ifndef FRIEND_H_
#define FRIEND_H_
#include <string>
#include "contact.h"
using namespace std;
class Friend:public contact
{
	string relation;
public:
	Friend(const string &);
	~Friend(){}
	string getRelationship();


};



#endif /* FRIEND_H_ */
