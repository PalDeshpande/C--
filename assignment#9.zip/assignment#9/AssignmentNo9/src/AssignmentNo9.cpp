//============================================================================
// Name        : AssignmentNo9.cpp
// Author      : Pallavi
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;
#include <string>

#include "contact.h"
#include "Friend.h"
#include "Enemy.h"
void printTarget(contact *);
void printTarget(Friend *);
void printTarget(Enemy *);

int main() {
	contact *mycontact = new contact("Mike");
	//can not use friend as class object name as it is key word
	Friend * myFriend = new Friend("Alex");
	Enemy * enemy = new Enemy("Jeff");

	printTarget(mycontact);
	printTarget(myFriend);
	printTarget(enemy);

	return 0;
}

void printTarget(contact * contact) {
	cout << contact->getRelationship() << endl;
}
//inorder to use getRelationship() of the derived classes
//derived class pointer needs to be used
void printTarget(Friend * Frnd) {
	cout << Frnd->getRelationship() << endl;
}

void printTarget(Enemy * enemy) {
	cout << enemy->getRelationship() << endl;
}

