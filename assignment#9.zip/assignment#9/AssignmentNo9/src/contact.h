/*
 * contact.h
 *
 *  Created on: Apr 22, 2012
 *      Author: Pallavi
 */

#ifndef CONTACT_H_
#define CONTACT_H_
#include <string>
using namespace std;

class contact{
	string name;
public:
	contact(const string&);
	~contact(){}
	void setName(string Nam);
	string getName();
	string getRelationship();

};



#endif /* CONTACT_H_ */
