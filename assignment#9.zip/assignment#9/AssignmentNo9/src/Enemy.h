/*
 * Enemy.h
 *
 *  Created on: Apr 22, 2012
 *      Author: Pallavi
 */

#ifndef ENEMY_H_
#define ENEMY_H_
#include <string>
#include "contact.h"
using namespace std;
class Enemy:public contact{
	string relation;
public:
	Enemy(const string &);
	~Enemy(){}
	string getRelationship();
};



#endif /* ENEMY_H_ */
