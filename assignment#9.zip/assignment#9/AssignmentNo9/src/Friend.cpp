/*
 * Friend.cpp
 *
 *  Created on: Apr 22, 2012
 *      Author: Pallavi
 */
#include <string>
#include "Friend.h"
#include "contact.h"

Friend::Friend(const string &strNam):contact(strNam){
relation = "friend";
}

string Friend::getRelationship(){
	string strName, relationStr;
		strName = getName();
		relationStr = "I am " + strName + " and I am a" + relation;
		return relationStr;
}



