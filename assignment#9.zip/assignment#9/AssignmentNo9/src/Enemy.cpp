/*
 * Enemy.cpp
 *
 *  Created on: Apr 22, 2012
 *      Author: Pallavi
 */
#include <string>
#include "Enemy.h"
#include "contact.h"

Enemy::Enemy(const string &strNam):contact(strNam){
	relation = "enemy";
}

string Enemy::getRelationship(){
	string strName, relationStr;
			strName = getName();
			relationStr = "I am " + strName + " and I am a" + relation;
			return relationStr;
}



