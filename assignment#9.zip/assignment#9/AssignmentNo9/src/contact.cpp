/*
 * contact.cpp
 *
 *  Created on: Apr 22, 2012
 *      Author: Pallavi
 */
#include <iostream>
#include <string>
#include "contact.h"
using namespace std;

contact::contact(const string &strname){
	setName(strname);
}

void contact::setName(string Nam){
	name = Nam;
}

string contact::getName(){
	return name;
}

string contact::getRelationship(){
	string strName, relationStr;
	strName = getName();
	relationStr = "I am contact of " + strName + " !";
	return relationStr;
}






